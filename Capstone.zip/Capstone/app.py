from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/decision', methods=['POST'])
def decision():
    step = request.form['step']
    answer = request.form['answer']

    if step == 'breathing' and answer == 'yes':
        return redirect(url_for('apply_high_flow_oxygen'))
    elif step == 'breathing' and answer == 'no':
        return redirect(url_for('call_resuscitation_team'))
    # Add more elif conditions based on the flowchart

    return redirect(url_for('index'))

@app.route('/apply_high_flow_oxygen')
def apply_high_flow_oxygen():
    return render_template('apply_high_flow_oxygen.html')

@app.route('/call_resuscitation_team')
def call_resuscitation_team():
    return render_template('call_resuscitation_team.html')

@app.route('/assess_stoma_patency')
def assess_stoma_patency():
    return render_template('assess_stoma_patency.html')

#Html not implemented yet
#Must remove before attempting to pass suction catheter
@app.route('/stoma_cover', methods=['POST'])
def stoma_cover():
    answer = request.form['answer']
    if answer == 'yes':
        return render_template('remove_stoma_cover.html')
    else:
        return render_template('no_stoma_cover.html')  # assuming there is a different path for "No"

#Html not implemented yet
@app.route('/suction_catheter', methods=['POST'])
def suction_catheter():
    answer = request.form['answer']
    if answer == 'yes':
        return render_template('can_pass_suction_catheter.html')
    else:
        return render_template('cannot_pass_suction_catheter.html')

#Html not implemented yet
@app.route('/remove_inner_tube', methods=['POST'])
def remove_inner_tube():
    answer = request.form['answer']
    if answer == 'yes':
        return render_template('remove_inner_tube.html')
    else:
        return render_template('deflate_cuff.html')


@app.route('/can_pass_suction_catheter')
def can_pass_suction_catheter():
    return render_template('can_pass_suction_catheter.html')

@app.route('/cannot_pass_suction_catheter')
def cannot_pass_suction_catheter():
    return render_template('cannot_pass_suction_catheter.html')



if __name__ == '__main__':
    app.run(debug=True)
