from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)

@app.route('/')
def index():
    # Render the starting point template with the first question
    return render_template('index.html')

@app.route('/step', methods=['POST'])
def step():
    # Retrieve the step from the form
    step = request.form.get('step')
    answer = request.form.get('answer')

    # Based on the step and answer, redirect to the appropriate next step
    if step == 'breathing':
        return redirect(url_for('apply_high_flow_oxygen' if answer == 'yes' else 'call_resuscitation_team'))

    # Add more conditions based on the steps in the flowchart
    # ...

    return redirect(url_for('index'))  # Redirect to index if an unknown step is encountered

# Define routes for different decisions
@app.route('/apply_high_flow_oxygen')
def apply_high_flow_oxygen():
    return render_template('apply_high_flow_oxygen.html')

@app.route('/call_resuscitation_team')
def call_resuscitation_team():
    return render_template('call_resuscitation_team.html')

@app.route('/assess_stoma_potency')
def assess_stoma_potency():
    return render_template('assess_stoma_potency.html')


if __name__ == '__main__':
    app.run(debug=True)
